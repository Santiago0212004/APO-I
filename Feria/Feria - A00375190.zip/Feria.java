/*

Santiago Jose Barraza Sinning - A00375190

-----------------------------------------------------------------Problema--------------------------------------------------------------------------------

Las entidades sanitarias y la alcaldía de Cali están preparando el plan para que el sueño de todos los caleños: La feria de Cali presencial, sea una 
realidad en diciembre del 2021.

Teniendo en cuenta que la pandemia continúa y que habrán muchas personas interesadas en participar, contactaron al grupo 1 de algoritmos y programación 
para que programe el prototipo de la aplicación que ayudará a las caleñas y los caleños a identificar en qué actividades pueden participar para conservar 
el aforo y el distanciamiento. 

La propuesta es la siguiente:

Considerando que las actividades se planean entre el 25 y el 30 de diciembre, es decir 6 días el pico y cédula se calcula aplicando la operación módulo  
6 a los dos últimos dígitos de la cédula así:

Si el módulo es 0, la persona puede salir el 25 de diciembre.
Si el módulo es 1, la persona puede salir el 26 de diciembre.
Si el módulo es 2, la persona puede salir el 27 de diciembre.
Si el módulo es 3, la persona puede salir el 28 de diciembre.
Si el módulo es 4, la persona puede salir el 29 de diciembre.
Si el módulo es 5, la persona puede salir el 30 de diciembre.

Ahora, para asegurarse que no haya aglomeraciones, existen unos horarios en los cuales las personas podrán participar de las actividades gratuitas 
programadas por la alcaldía. 

Los menores de 18 años pueden participar de las actividades entre las 9:00 am y las 12:00m
Las personas entre los 18 y los 40 años pueden participar en las actividades entre las 10:00 pm y las 3:00am
Las personas mayores de 40 y menores 65 pueden asistir a las actividades entre las 18:00 y las 12:00 pm (media noche)
Los adultos mayores, o personas  de 65 años en adelante pueden asistir a las actividades entre las 12:00 m y las 18:00. 

Escriba un programa para que dados  el número de cédula  y el año en que nació una persona le informe a un ciudadano el día y el horario en que puede 
disfrutar de la feria de Cali. 

Subrutinas:

-----------------------------------------------------------------Subrutina "fecha_salir"--------------------------------------------------------------------

Objetivo: Hallar, a partir del numero de cedula, el dia en el cual la persona puede salir.

Entradas: 

    - Cedula de la persona que quiere ir a la feria. (Variable: cedula , Tipo: long)

Salidas:

    - Dia en el cual la persona la persona puede salir para ir a la feria (Variable: dia , Tipo: int)

Funcionamiento (paso a paso):

    1. Recibe como unico parametro la cedula.

    2. Saca el residuo de dividir el numero de la cedula entre 100. Esto para sacar los dos ultimos digitos.

    3. Saca el residuo de dividir el numero conformado por los dos ultimos digitos entre 6. Esto para saber a que caso aplica.

    4. Dependiendo del resultado anterior, usa un "switch" para evaluar de 0-6 (unicos casos posibles), y luego asigna a la variable "dia" el dia 
       correspondiente.

    5. La subrutina retorna el valor de "dia", dandonos asi, el dia de la feria al que puede asistir.

Ejemplo:

    cedula = 1044607243
    
    ultimos_digitos = cedula % 100 = 1044607243 % 100 = 43

    modulo = ultimos_digitos % 6 = 43 % 6 = 1

    Aplica "case 1"

    dia = 26

-----------------------------------------------------------------Subrutina "hora_salir"--------------------------------------------------------------------

Objetivo: Hallar, a partir del año de nacimiento, el horario en el cual la persona puede salir.

Entradas: 

    - Año de nacimiento de la persona que quiere asistir a la feria. (Variale: anio , Tipo: int)

Salidas:

    - Horario en el cual la persona la persona puede salir para ir a la feria (Variable: horario , Tipo: String)

Funcionamiento (paso a paso):

    1. Recibe como unico parametro el año de nacimiento.

    2. Halla la edad de la persona, restando el año de nacimiento a 2021 (año actual).

    3. Evalua los rangos especificados en el problema, asignando a "horario" el rango de horas del dia correspondiente a cada uno de estos. Para eso se usa
       una estructura conformada por bloques "if, else-if..., else".

    4. La subrutina retorna el valor de "horario", dandonos asi, el rango de horas en el que la persona puede estar presente en la feria.

Ejemplo:

    anio = 2004
    
    edad = 2021 - anio = 2021 - 2004 = 17

    aplica la condicion "if(edad>0 && edad<18)"

    horario = "9:00am a 12:00pm."
*/

//-------------------------------------------------------------------------Codigo-------------------------------------------------------------------------------------------

import java.util.Scanner;

public class Feria{

    public static int fecha_salir(long cedula){
        int ultimos_digitos = (int) cedula%100;
        int modulo =  ultimos_digitos%6;
        int dia = 0;

        switch(modulo){
            case 0:
                dia = 25;
                break;
            case 1:
                dia = 26;
                break;
            case 2:
                dia = 27;
                break;
            case 3:
                dia = 28;
                break;
            case 4:
                dia = 29;
                break;
            case 5:
                dia = 30;
                break;
        }

    return dia;

    }

    public static String hora_salir(int anio){
        int edad = 2021 - anio;
        String horario = "";

        if(edad>0 && edad<18){
            horario = "9:00am a 12:00pm.";
        }
        else if(edad>=18 && edad<=40){
            horario = "10:00pm a 3:00am.";
        }
        else if(edad>40 && edad<65){
            horario = "6:00pm a 12:00am.";
        }
        else{
            horario = "12:00pm a 6:00pm.";
        }

        return horario;
    }

    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        System.out.println("Escriba su numero de cedula: ");
        long cedula = sc.nextInt();

        System.out.println("Escriba su anio de nacimiento: ");
        int anio = sc.nextInt();


        System.out.println("Usted puede salir a la feria el "+fecha_salir(cedula)+" de diciembre de "+hora_salir(anio));
    }
}