package model;

public enum Category {
    ROMANTIC, ACTION, SUSPENSE, HORROR, COMEDY;
}
