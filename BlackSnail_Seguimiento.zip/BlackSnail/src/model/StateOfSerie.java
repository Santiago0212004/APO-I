package model;

public enum StateOfSerie {
    CENSORED, UNCENSORED;  
}
