package model;

public enum SubscriberState {
	ACTIVE, INACTIVE; //All possible values of State
}