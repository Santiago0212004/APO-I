package model;

public enum State {
	ACTIVE, INACTIVE; //All possible values of State

}