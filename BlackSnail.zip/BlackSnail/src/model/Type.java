package model;

public enum Type {
	NORMAL, GOLD, PLATINUM, DIAMOND; //All possible values of Type

}