package model;

public  class BMTBicycle implements Bicycle{

	public void changeCadence(int newValue){

	}

    public void changeGear(int newValue){

    }

    public void speedUp(int increment){

    }

    public void applyBrakes(int decrement){
    	
    }



	
}