package model;

public enum Behavior {
    NONE, GOOD, BAD;
}
