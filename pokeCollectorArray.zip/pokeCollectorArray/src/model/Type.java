package model;

public enum Type {
	WATER, FIRE, GOSTH, ELECTRIC, POISON

}
