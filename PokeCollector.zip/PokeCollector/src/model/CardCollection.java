package model;

public class CardCollection{
    private String ownerName;

    private Album album1;
    private Album album2;
    private Album album3;
    private Album album4;

    private Date creationDate;
}