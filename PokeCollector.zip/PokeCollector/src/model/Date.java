package model;

public class Date{
    private int day;
    private int month;
    private int year;
}