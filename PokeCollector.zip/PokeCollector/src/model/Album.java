package model;

public class Album{
    private String region;
    private int pokemonQuantity;

    private Pokemon albumPokemon;
    private Map regionMap;
}