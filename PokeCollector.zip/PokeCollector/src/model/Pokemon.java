package model;

public class Pokemon{
    private String name;
    private String type;
    private String specie;
    private int healthPoints;
    private int attackPoints;
    private int powerPoints;
    private int defensePoints;
}