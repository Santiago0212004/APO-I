package model;

public class Map{
    private String imagePath;
    private Date pictureDate;

    private Coordinate latitude;
    private Coordinate longitude;

}