package model;

public class Coordinate{
    private double degree;
    private double minutes;
    private double seconds;
}