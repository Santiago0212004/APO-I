package ui;

import model.CardCollection;
import java.util.Scanner;

public class PokeCollector{

    private CardCollection myCollection;

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args){
        System.out.println("Escriba el nombre del entrenador pokemon: ");
        String ownerName = sc.next();
    }

}